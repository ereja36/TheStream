package com.app.thestreamapp.listener;

public interface OnCompleteListener {

    void onComplete();

}