package com.app.thestreamapp.callbacks;

import com.app.thestreamapp.models.Ads;

public class CallbackAds {

    public String status;
    public Ads ads = null;

}
