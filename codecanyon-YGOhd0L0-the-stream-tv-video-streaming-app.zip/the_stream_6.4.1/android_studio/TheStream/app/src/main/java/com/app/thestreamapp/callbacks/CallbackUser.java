package com.app.thestreamapp.callbacks;

import com.app.thestreamapp.models.User;

import java.util.ArrayList;
import java.util.List;

public class CallbackUser {

    public List<User> users = new ArrayList<>();
    public String message = "";

}