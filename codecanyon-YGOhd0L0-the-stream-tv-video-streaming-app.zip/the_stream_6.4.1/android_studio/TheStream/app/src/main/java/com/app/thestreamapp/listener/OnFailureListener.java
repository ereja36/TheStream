package com.app.thestreamapp.listener;

public interface OnFailureListener {

    void onFailure();

}