package com.app.thestreamapp.listener;

public interface OnPositiveButtonListener {

    void onPositive();

}