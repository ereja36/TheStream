package com.shif.shqip.android;

import com.shif.shqip.android.utils.Constant;

public class Config {

    //your Server Key obtained from admin panel
    public static final String SERVER_KEY = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

    //your Rest API Key obtained the admin panel
    public static final String REST_API_KEY = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

    //bottom navigation menu configuration
    public static final boolean SET_CATEGORY_AS_MAIN_MENU = false;

    //dark theme configuration
    public static final boolean SET_DARK_MODE_AS_DEFAULT_THEME = false;

    //available channel view type : CHANNEL_LIST_DEFAULT, CHANNEL_GRID_2_COLUMN or CHANNEL_GRID_3_COLUMN
    public static final int CHANNEL_VIEW_TYPE = Constant.CHANNEL_LIST_DEFAULT;

    //available channel view type : CATEGORY_LIST_DEFAULT, CATEGORY_GRID_2_COLUMN or CATEGORY_GRID_3_COLUMN
    public static final int CATEGORY_VIEW_TYPE = Constant.CATEGORY_GRID_3_COLUMN;

    //available player screen orientation : PLAYER_MODE_PORTRAIT or PLAYER_MODE_LANDSCAPE
    public static final int DEFAULT_PLAYER_SCREEN_ORIENTATION = Constant.PLAYER_MODE_PORTRAIT;

    //show option to play streaming using external player
    public static final boolean ENABLE_PLAY_STREAMING_USING_EXTERNAL_PLAYER = true;

    //display category name in the channel list
    public static final boolean ENABLE_CHANNEL_LIST_CATEGORY_NAME = true;

    //highly recommended to keep with false value to prevent the app accessed using VPN for security reason
    public static final boolean ENABLE_VPN_ACCESS = false;

    //press back twice to exit from player screen
    public static final boolean PRESS_BACK_TWICE_TO_CLOSE_PLAYER = false;

    //if you use RTL Language e.g : Arabic Language or other, set true
    public static final boolean ENABLE_RTL_MODE = false;

    //load more pagination
    public static final int LOAD_MORE = 12;

    //looping mode
    public static final boolean ENABLE_LOOPING_MODE = false;

    //display dialog for exit confirmation
    public static final boolean ENABLE_EXIT_DIALOG = true;

    //GDPR
    public static final boolean ENABLE_GDPR_EU_CONSENT = true;

    //delay splash screen
    public static final int DELAY_SPLASH = 500;

    //Enable it with true value if want to the app will force to display open ads first before start the main menu
    //Longer duration to start the app may occur depending on internet connection or open ad response time itself
    public static final boolean FORCE_TO_SHOW_APP_OPEN_AD_ON_START = false;

}