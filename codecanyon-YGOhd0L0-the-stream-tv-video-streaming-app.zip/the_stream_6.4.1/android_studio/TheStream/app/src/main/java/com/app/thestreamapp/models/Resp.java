package com.app.thestreamapp.models;

import java.io.Serializable;

public class Resp implements Serializable {

    public String value;
    public String message;

}