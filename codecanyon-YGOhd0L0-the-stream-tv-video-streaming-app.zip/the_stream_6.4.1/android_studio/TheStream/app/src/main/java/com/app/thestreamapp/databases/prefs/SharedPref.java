package com.app.thestreamapp.databases.prefs;

import static com.app.thestreamapp.Config.CATEGORY_VIEW_TYPE;
import static com.app.thestreamapp.Config.CHANNEL_VIEW_TYPE;
import static com.app.thestreamapp.Config.DEFAULT_PLAYER_SCREEN_ORIENTATION;

import android.content.Context;
import android.content.SharedPreferences;

import com.app.thestreamapp.BuildConfig;
import com.app.thestreamapp.Config;
import com.app.thestreamapp.models.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SharedPref {

    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public SharedPref(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(BuildConfig.APPLICATION_ID + "_" + "shared_preferences", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public Boolean getIsDarkTheme() {
        return sharedPreferences.getBoolean("theme", Config.SET_DARK_MODE_AS_DEFAULT_THEME);
    }

    public void setIsDarkTheme(Boolean isDarkTheme) {
        editor.putBoolean("theme", isDarkTheme);
        editor.apply();
    }

    public void setDialogPlayerOption(boolean dialogPlayerOption) {
        editor.putBoolean("dialog_player_option", dialogPlayerOption);
        editor.apply();
    }

    public boolean getIsDialogPlayerOption() {
        return sharedPreferences.getBoolean("dialog_player_option", true);
    }

    public void setPlayerPosition(int position) {
        editor.putInt("player_position", position);
        editor.apply();
    }

    public Integer getPlayerPosition() {
        return sharedPreferences.getInt("player_position", 0);
    }

    public Integer getChannelViewType() {
        return sharedPreferences.getInt("video_list", CHANNEL_VIEW_TYPE);
    }

    public void updateChannelViewType(int position) {
        editor.putInt("video_list", position);
        editor.apply();
    }

    public Integer getCategoryViewType() {
        return sharedPreferences.getInt("category_list", CATEGORY_VIEW_TYPE);
    }

    public void updateCategoryViewType(int position) {
        editor.putInt("category_list", position);
        editor.apply();
    }

    public Integer getPlayerOrientation() {
        return sharedPreferences.getInt("player_mode", DEFAULT_PLAYER_SCREEN_ORIENTATION);
    }

    public void updatePlayerOrientation(int position) {
        editor.putInt("player_mode", position);
        editor.apply();
    }

    public void saveConfig(String api_url, String application_id) {
        editor.putString("api_url", api_url);
        editor.putString("application_id", application_id);
        editor.apply();
    }

    public String getBaseUrl() {
        return sharedPreferences.getString("api_url", "http://10.0.2.2/the_stream");
    }

    public String getApplicationId() {
        return sharedPreferences.getString("application_id", "com.app.thestream");
    }

    public void saveCredentials(String youtube_api_key, String more_apps_url, String privacy_policy, String redirect_url, String pushNotificationProvider) {
        editor.putString("youtube_api_key", youtube_api_key);
        editor.putString("more_apps_url", more_apps_url);
        editor.putString("privacy_policy", privacy_policy);
        editor.putString("redirect_url", redirect_url);
        editor.putString("providers", pushNotificationProvider);
        editor.apply();
    }

    public String getYoutubeAPIKey() {
        return sharedPreferences.getString("youtube_api_key", "0");
    }

    public String getPrivacyPolicy() {
        return sharedPreferences.getString("privacy_policy", "");
    }

    public String getMoreAppsUrl() {
        return sharedPreferences.getString("more_apps_url", "https://play.google.com/store/apps/developer?id=Solodroid");
    }

    public Integer getInAppReviewToken() {
        return sharedPreferences.getInt("in_app_review_token", 0);
    }

    public void updateInAppReviewToken(int value) {
        editor.putInt("in_app_review_token", value);
        editor.apply();
    }

    public String getRedirectUrl() {
        return sharedPreferences.getString("redirect_url", "");
    }

    public String getPushNotificationProvider() {
        return sharedPreferences.getString("providers", "");
    }

    public void saveUser(String itemId, String itemName, String buyer, String licenseType) {
        editor.putString("item_id", itemId);
        editor.putString("item_name", itemName);
        editor.putString("buyer", buyer);
        editor.putString("license_type", licenseType);
        editor.apply();
    }

    public String getItemId() {
        return sharedPreferences.getString("item_id", "");
    }

    public String getItemName() {
        return sharedPreferences.getString("item_name", "");
    }

    public String getBuyer() {
        return sharedPreferences.getString("buyer", "");
    }

    public String getLicenseType() {
        return sharedPreferences.getString("license_type", "");
    }

    public void saveUserList(List<User> users) {
        Gson gson = new Gson();
        String json = gson.toJson(users);
        editor.putString("key_user", json);
        editor.apply();
    }

    public List<User> getUserList() {
        Gson gson = new Gson();
        String json = sharedPreferences.getString("key_user", null);
        Type type = new TypeToken<ArrayList<User>>() {
        }.getType();
        return gson.fromJson(json, type);
    }

}
