package com.app.thestreamapp.models;

import java.io.Serializable;

public class User implements Serializable {

    public String item_id = "";
    public String buyer = "";

}
