package com.shif.shqip.android.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.shif.shqip.android.R;
import com.shif.shqip.android.databases.prefs.SharedPref;
import com.shif.shqip.android.utils.Tools;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ActivityPlaylistSetup extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_FILE = 2001;
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private SharedPref sharedPref;
    private OnBackPressedDispatcher onBackPressedDispatcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_playlist_setup);
        Tools.setNavigation(this);
        sharedPref = new SharedPref(this);

        setupToolbar();
        setupButtons();
        handleOnBackPressed();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        Tools.setupToolbar(this, toolbar, getString(R.string.playlist_setup_title), true);
    }

    private void setupButtons() {
        findViewById(R.id.btn_add_playlist).setOnClickListener(v -> showPlaylistUrlDialog());
        findViewById(R.id.btn_open_file).setOnClickListener(v -> openPlaylistFile());
        findViewById(R.id.btn_play_url).setOnClickListener(v -> showStreamUrlDialog());
    }

    private void showPlaylistUrlDialog() {
        final EditText editText = new EditText(this);
        editText.setHint(getString(R.string.playlist_url_hint));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        editText.setText(sharedPref.getPlaylistUrl());
        int padding = (int) getResources().getDimension(R.dimen.settings_space);
        editText.setPadding(padding, padding, padding, padding);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.playlist_add)
                .setMessage(R.string.playlist_add_dialog_message)
                .setView(editText)
                .setPositiveButton(R.string.dialog_ok, (dialog, which) -> {
                    String playlistUrl = editText.getText().toString().trim();
                    if (TextUtils.isEmpty(playlistUrl)) {
                        showToast(getString(R.string.playlist_error_empty_url));
                        return;
                    }
                    fetchAndSavePlaylist(playlistUrl);
                })
                .setNegativeButton(R.string.dialog_cancel, null)
                .show();
    }

    private void showStreamUrlDialog() {
        final EditText editText = new EditText(this);
        editText.setHint(getString(R.string.playlist_stream_url_hint));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        int padding = (int) getResources().getDimension(R.dimen.settings_space);
        editText.setPadding(padding, padding, padding, padding);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.playlist_play_url)
                .setMessage(R.string.playlist_play_url_dialog_message)
                .setView(editText)
                .setPositiveButton(R.string.dialog_ok, (dialog, which) -> {
                    String streamUrl = editText.getText().toString().trim();
                    if (TextUtils.isEmpty(streamUrl)) {
                        showToast(getString(R.string.playlist_error_empty_url));
                        return;
                    }
                    sharedPref.savePlaylistUrl(streamUrl);
                    openPlayer(streamUrl);
                })
                .setNegativeButton(R.string.dialog_cancel, null)
                .show();
    }

    private void fetchAndSavePlaylist(String playlistUrl) {
        showToast(getString(R.string.playlist_loading));
        executorService.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(playlistUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();
                if (responseCode < 200 || responseCode >= 300) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_download)));
                    return;
                }

                String content = readAll(connection.getInputStream());
                String firstStreamUrl = parseFirstPlayableUrl(content);
                if (TextUtils.isEmpty(firstStreamUrl)) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }

                runOnUiThread(() -> {
                    sharedPref.savePlaylistUrl(firstStreamUrl);
                    showToast(getString(R.string.playlist_saved));
                    openPlayer(firstStreamUrl);
                });
            } catch (Exception e) {
                runOnUiThread(() -> showToast(getString(R.string.playlist_error_download)));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }

    private void openPlaylistFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_CODE_PICK_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) {
                showToast(getString(R.string.playlist_error_invalid_file));
                return;
            }
            readPlaylistFromFile(uri);
        }
    }

    private void readPlaylistFromFile(Uri uri) {
        executorService.execute(() -> {
            try (InputStream inputStream = getContentResolver().openInputStream(uri)) {
                if (inputStream == null) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }
                String content = readAll(inputStream);
                String firstStreamUrl = parseFirstPlayableUrl(content);
                if (TextUtils.isEmpty(firstStreamUrl)) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }

                runOnUiThread(() -> {
                    sharedPref.savePlaylistUrl(firstStreamUrl);
                    showToast(getString(R.string.playlist_saved));
                    openPlayer(firstStreamUrl);
                });
            } catch (Exception e) {
                runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
            }
        });
    }

    private String readAll(InputStream inputStream) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append('\n');
            }
        }
        return builder.toString();
    }

    private String parseFirstPlayableUrl(String content) {
        if (TextUtils.isEmpty(content)) {
            return "";
        }
        String[] lines = content.split("\\r?\\n");
        for (String line : lines) {
            String candidate = line.trim();
            if (candidate.isEmpty() || candidate.startsWith("#")) {
                continue;
            }
            if (candidate.startsWith("http://")
                    || candidate.startsWith("https://")
                    || candidate.startsWith("rtsp://")
                    || candidate.startsWith("rtmp://")) {
                return candidate;
            }
        }
        return "";
    }

    private void openPlayer(String streamUrl) {
        Intent intent = new Intent(getApplicationContext(), ActivityPlayerVideo.class);
        intent.putExtra("channel_id", "");
        intent.putExtra("url", streamUrl);
        intent.putExtra("user_agent", "default");
        startActivity(intent);
        finish();
    }

    private void handleOnBackPressed() {
        onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdownNow();
    }
}
