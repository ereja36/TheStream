package com.app.thestreamapp.callbacks;

import com.app.thestreamapp.models.Ads;
import com.app.thestreamapp.models.App;
import com.app.thestreamapp.models.License;
import com.app.thestreamapp.models.Settings;

public class CallbackConfig {

    public String status;
    public App app = null;
    public Settings settings = null;
    public Ads ads = null;
    public License license = null;

}
