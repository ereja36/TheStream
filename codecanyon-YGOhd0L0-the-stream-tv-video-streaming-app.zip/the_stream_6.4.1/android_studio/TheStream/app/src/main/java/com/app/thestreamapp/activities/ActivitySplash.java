package com.app.thestreamapp.activities;

import static com.app.thestreamapp.Config.ENABLE_VPN_ACCESS;
import static com.app.thestreamapp.utils.Constant.LOCALHOST_ADDRESS;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.app.thestreamapp.Config;
import com.app.thestreamapp.R;
import com.app.thestreamapp.callbacks.CallbackConfig;
import com.app.thestreamapp.databases.prefs.AdsPref;
import com.app.thestreamapp.databases.prefs.SharedPref;
import com.app.thestreamapp.models.Ads;
import com.app.thestreamapp.models.App;
import com.app.thestreamapp.models.License;
import com.app.thestreamapp.models.Settings;
import com.app.thestreamapp.rests.RestAdapter;
import com.app.thestreamapp.utils.AdsManager;
import com.app.thestreamapp.utils.Constant;
import com.app.thestreamapp.utils.Tools;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.solodroidx.ads.appopen.AppOpenAd;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivitySplash extends AppCompatActivity {

    public static final String TAG = "ActivitySplash";
    Call<CallbackConfig> callbackCall = null;
    ImageView img_splash;
    SharedPref sharedPref;
    AdsManager adsManager;
    AdsPref adsPref;
    App app;
    Settings settings;
    Ads ads;
    License license;
    boolean isForceOpenAds;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.transparentStatusBarNavigation(ActivitySplash.this);
        setContentView(R.layout.activity_splash);
        isForceOpenAds = Config.FORCE_TO_SHOW_APP_OPEN_AD_ON_START;
        adsManager = new AdsManager(this);
        sharedPref = new SharedPref(this);
        adsPref = new AdsPref(this);

        img_splash = findViewById(R.id.img_splash);
        if (sharedPref.getIsDarkTheme()) {
            img_splash.setImageResource(R.drawable.bg_splash_dark);
        } else {
            img_splash.setImageResource(R.drawable.bg_splash_default);
        }

        if (ENABLE_VPN_ACCESS) {
            Tools.postDelayed(this::requestConfig, Config.DELAY_SPLASH);
        } else {
            if (Tools.isVpnConnectionAvailable()) {
                Tools.showWarningDialog(ActivitySplash.this, getString(R.string.vpn_detected), getString(R.string.close_vpn));
            } else {
                Tools.postDelayed(this::requestConfig, Config.DELAY_SPLASH);
            }
        }
    }

    @SuppressWarnings("ConstantValue")
    private void requestConfig() {
        if (Config.SERVER_KEY.contains("XXXXX")) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("App not configured")
                    .setMessage("Please put your Server Key and Rest API Key from settings menu in your admin panel to AppConfig, you can see the documentation for more detailed instructions.")
                    .setPositiveButton(getString(R.string.dialog_ok), (dialogInterface, i) -> startMainActivity())
                    .setCancelable(false)
                    .show();
        } else {
            String data = Tools.decode(Config.SERVER_KEY);
            String[] results = data.split("_applicationId_");
            String baseUrl = results[0].replace("localhost", LOCALHOST_ADDRESS);
            String applicationId = results[1];
            sharedPref.saveConfig(baseUrl, applicationId);

            if (applicationId.equals(Tools.getApplicationId())) {
                if (Tools.isConnect(this)) {
                    requestAPI(baseUrl);
                } else {
                    startMainActivity();
                }
            } else {
                String message = "applicationId does not match, applicationId in your app is : " + Tools.getApplicationId() +
                        "\n\n But your Server Key is registered with applicationId : " + applicationId + "\n\n" +
                        "Please update your Server Key with the appropriate registration applicationId that is used in your Android project.";
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Error")
                        .setMessage(Html.fromHtml(message))
                        .setPositiveButton(getString(R.string.dialog_ok), (dialog, which) -> finish())
                        .setCancelable(false)
                        .show();
            }
        }
    }

    private void requestAPI(String apiUrl) {
        this.callbackCall = RestAdapter.createAPI(apiUrl).getConfig(Tools.getApplicationId(), Config.REST_API_KEY);
        this.callbackCall.enqueue(new Callback<>() {
            public void onResponse(@NonNull Call<CallbackConfig> call, @NonNull Response<CallbackConfig> response) {
                CallbackConfig resp = response.body();
                if (resp != null && resp.status.equals("ok")) {
                    app = resp.app;
                    settings = resp.settings;
                    ads = resp.ads;
                    license = resp.license;
                    Tools.saveAds(adsPref, ads);
                    sharedPref.saveCredentials(settings.youtube_api_key, settings.more_apps_url, settings.privacy_policy, app.redirect_url, settings.providers);
                    sharedPref.saveUser(license.item_id, license.item_name, license.buyer, license.license_type);
                    if (app.status != null && app.status.equals("0")) {
                        Intent intent = new Intent(getApplicationContext(), ActivityRedirect.class);
                        intent.putExtra("redirect_url", app.redirect_url);
                        startActivity(intent);
                        finish();
                        Log.d(TAG, "App is inactive, call redirect method");
                    } else {
                        showAppOpenAdIfAvailable();
                        Log.d(TAG, "App is active");
                    }
                } else {
                    startMainActivity();
                    Log.d(TAG, "Resp null");
                }
            }

            public void onFailure(@NonNull Call<CallbackConfig> call, @NonNull Throwable th) {
                Log.e("onFailure", "onFailure: " + th.getMessage());
                startMainActivity();
            }
        });

    }

    private void showAppOpenAdIfAvailable() {
        if (isForceOpenAds) {
            if (Constant.APP_OPEN_AD_ON_START) {
                adsManager.loadAppOpenAd(Constant.APP_OPEN_AD_ON_START, true, () -> {
                    startMainActivity();
                    AppOpenAd.isAppOpenAdLoaded = false;
                    Log.d(TAG, "showAppOpenAdIfAvailable");
                });
            } else {
                startMainActivity();
                Log.d(TAG, "app open on start disabled");
            }
        } else {
            if (adsPref.getAdStatus() && Constant.APP_OPEN_AD_ON_START) {
                Application application = getApplication();
                ((MyApplication) application).showAdIfAvailable(this, this::startMainActivity);
            } else {
                startMainActivity();
                Log.d(TAG, "startMainActivity");
            }
        }
    }

    private void startMainActivity() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        AppOpenAd.isAppOpenAdLoaded = false;
    }

}