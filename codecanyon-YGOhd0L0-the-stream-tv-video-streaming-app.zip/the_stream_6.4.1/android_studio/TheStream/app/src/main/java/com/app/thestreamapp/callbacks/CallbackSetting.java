package com.app.thestreamapp.callbacks;

import com.app.thestreamapp.models.Settings;

public class CallbackSetting {

    public String status;
    public Settings post = null;

}
