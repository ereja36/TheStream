package com.app.thestreamapp.listener;

public interface OnSuccessListener {

    void onSuccess();

}