package com.app.thestreamapp.listener;

public interface OnErrorListener {

    void onError();

}