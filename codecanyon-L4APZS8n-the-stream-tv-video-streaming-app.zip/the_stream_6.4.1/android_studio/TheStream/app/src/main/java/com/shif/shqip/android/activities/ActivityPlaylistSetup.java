package com.shif.shqip.android.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.OnBackPressedDispatcher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.shif.shqip.android.R;
import com.shif.shqip.android.databases.prefs.SharedPref;
import com.shif.shqip.android.models.Channel;
import com.shif.shqip.android.utils.Tools;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ActivityPlaylistSetup extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_FILE = 2001;
    private static final Pattern ATTRIBUTE_PATTERN = Pattern.compile("([a-zA-Z0-9\\-]+)=\"([^\"]*)\"");
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private SharedPref sharedPref;
    private OnBackPressedDispatcher onBackPressedDispatcher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_playlist_setup);
        Tools.setNavigation(this);
        sharedPref = new SharedPref(this);

        setupToolbar();
        setupButtons();
        handleOnBackPressed();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        Tools.setupToolbar(this, toolbar, getString(R.string.playlist_setup_title), true);
    }

    private void setupButtons() {
        findViewById(R.id.btn_add_playlist).setOnClickListener(v -> showPlaylistUrlDialog());
        findViewById(R.id.btn_open_file).setOnClickListener(v -> openPlaylistFile());
        findViewById(R.id.btn_play_url).setOnClickListener(v -> showStreamUrlDialog());
    }

    private void showPlaylistUrlDialog() {
        final EditText editText = new EditText(this);
        editText.setHint(getString(R.string.playlist_url_hint));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        editText.setText(sharedPref.getPlaylistUrl());
        int padding = (int) getResources().getDimension(R.dimen.settings_space);
        editText.setPadding(padding, padding, padding, padding);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.playlist_add)
                .setMessage(R.string.playlist_add_dialog_message)
                .setView(editText)
                .setPositiveButton(R.string.dialog_ok, (dialog, which) -> {
                    String playlistUrl = editText.getText().toString().trim();
                    if (TextUtils.isEmpty(playlistUrl)) {
                        showToast(getString(R.string.playlist_error_empty_url));
                        return;
                    }
                    fetchAndSavePlaylist(playlistUrl);
                })
                .setNegativeButton(R.string.dialog_cancel, null)
                .show();
    }

    private void showStreamUrlDialog() {
        final EditText editText = new EditText(this);
        editText.setHint(getString(R.string.playlist_stream_url_hint));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        int padding = (int) getResources().getDimension(R.dimen.settings_space);
        editText.setPadding(padding, padding, padding, padding);

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.playlist_play_url)
                .setMessage(R.string.playlist_play_url_dialog_message)
                .setView(editText)
                .setPositiveButton(R.string.dialog_ok, (dialog, which) -> {
                    String streamUrl = editText.getText().toString().trim();
                    if (TextUtils.isEmpty(streamUrl)) {
                        showToast(getString(R.string.playlist_error_empty_url));
                        return;
                    }
                    List<Channel> channels = new ArrayList<>();
                    channels.add(createDirectChannel(streamUrl));
                    savePlaylistAndOpenMain(channels, streamUrl);
                })
                .setNegativeButton(R.string.dialog_cancel, null)
                .show();
    }

    private void fetchAndSavePlaylist(String playlistUrl) {
        showToast(getString(R.string.playlist_loading));
        executorService.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(playlistUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();
                if (responseCode < 200 || responseCode >= 300) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_download)));
                    return;
                }

                String content = readAll(connection.getInputStream());
                List<Channel> channels = parsePlaylistChannels(content);
                if (channels.isEmpty()) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }

                runOnUiThread(() -> {
                    savePlaylistAndOpenMain(channels, playlistUrl);
                });
            } catch (Exception e) {
                runOnUiThread(() -> showToast(getString(R.string.playlist_error_download)));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }

    private void openPlaylistFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_CODE_PICK_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) {
                showToast(getString(R.string.playlist_error_invalid_file));
                return;
            }
            readPlaylistFromFile(uri);
        }
    }

    private void readPlaylistFromFile(Uri uri) {
        executorService.execute(() -> {
            try (InputStream inputStream = getContentResolver().openInputStream(uri)) {
                if (inputStream == null) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }
                String content = readAll(inputStream);
                List<Channel> channels = parsePlaylistChannels(content);
                if (channels.isEmpty()) {
                    runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
                    return;
                }

                runOnUiThread(() -> {
                    savePlaylistAndOpenMain(channels, uri.toString());
                });
            } catch (Exception e) {
                runOnUiThread(() -> showToast(getString(R.string.playlist_error_invalid_file)));
            }
        });
    }

    private String readAll(InputStream inputStream) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line).append('\n');
            }
        }
        return builder.toString();
    }

    private List<Channel> parsePlaylistChannels(String content) {
        List<Channel> channels = new ArrayList<>();
        if (TextUtils.isEmpty(content)) {
            return channels;
        }

        String[] lines = content.split("\\r?\\n");
        String extInfoLine = "";
        String userAgent = "default";
        int index = 0;

        for (String rawLine : lines) {
            String line = rawLine == null ? "" : rawLine.trim();
            if (line.isEmpty()) {
                continue;
            }

            if (line.startsWith("#EXTINF")) {
                extInfoLine = line;
                continue;
            }

            if (line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                String value = line.substring("#EXTVLCOPT:http-user-agent=".length()).trim();
                if (!TextUtils.isEmpty(value)) {
                    userAgent = value;
                }
                continue;
            }

            if (line.startsWith("#")) {
                continue;
            }

            if (!isPlayableStreamUrl(line)) {
                continue;
            }

            index++;
            Channel channel = buildChannel(extInfoLine, line, userAgent, index);
            channels.add(channel);
            extInfoLine = "";
            userAgent = "default";
        }

        return channels;
    }

    private Channel buildChannel(String extInfoLine, String streamUrl, String userAgent, int index) {
        Channel channel = new Channel();
        String channelName = extractChannelName(extInfoLine);
        if (TextUtils.isEmpty(channelName)) {
            channelName = "Channel " + index;
        }
        String categoryName = extractAttribute(extInfoLine, "group-title");
        if (TextUtils.isEmpty(categoryName)) {
            categoryName = "TV";
        }

        channel.channel_id = "m3u_" + index;
        channel.channel_name = channelName;
        channel.channel_image = extractAttribute(extInfoLine, "tvg-logo");
        channel.channel_url = streamUrl;
        channel.channel_description = "";
        channel.channel_type = "M3U";
        channel.video_id = "";
        channel.category_name = categoryName.trim();
        channel.user_agent = TextUtils.isEmpty(userAgent) ? "default" : userAgent;
        channel.total_views = "0";
        return channel;
    }

    private Channel createDirectChannel(String streamUrl) {
        Channel channel = new Channel();
        channel.channel_id = "direct_1";
        channel.channel_name = "Direct Stream";
        channel.channel_image = "";
        channel.channel_url = streamUrl;
        channel.channel_description = "";
        channel.channel_type = "M3U";
        channel.video_id = "";
        channel.category_name = "TV";
        channel.user_agent = "default";
        channel.total_views = "0";
        return channel;
    }

    private boolean isPlayableStreamUrl(String url) {
        String lower = url.toLowerCase(Locale.US);
        return lower.startsWith("http://")
                || lower.startsWith("https://")
                || lower.startsWith("rtsp://")
                || lower.startsWith("rtmp://")
                || lower.startsWith("udp://")
                || lower.startsWith("mms://");
    }

    private String extractChannelName(String extInfoLine) {
        if (TextUtils.isEmpty(extInfoLine)) {
            return "";
        }
        int commaIndex = extInfoLine.indexOf(',');
        if (commaIndex == -1 || commaIndex >= extInfoLine.length() - 1) {
            String tvgName = extractAttribute(extInfoLine, "tvg-name");
            return TextUtils.isEmpty(tvgName) ? "" : tvgName.trim();
        }
        return extInfoLine.substring(commaIndex + 1).trim();
    }

    private String extractAttribute(String line, String key) {
        if (TextUtils.isEmpty(line)) {
            return "";
        }
        Matcher matcher = ATTRIBUTE_PATTERN.matcher(line);
        while (matcher.find()) {
            String attrName = matcher.group(1);
            if (key.equalsIgnoreCase(attrName)) {
                String value = matcher.group(2);
                return value == null ? "" : value.trim();
            }
        }
        return "";
    }

    private void savePlaylistAndOpenMain(List<Channel> channels, String playlistSource) {
        sharedPref.savePlaylistUrl(playlistSource);
        sharedPref.savePlaylistChannels(channels);
        showToast(getString(R.string.playlist_saved));
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void handleOnBackPressed() {
        onBackPressedDispatcher = getOnBackPressedDispatcher();
        onBackPressedDispatcher.addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                finish();
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdownNow();
    }
}
